"""
Author's: Coral S. Schmidt Montilla
          Gabriel O. Gonzales Rios
          Kevin Gabriel Quintero Ramires
Student Numbers: #148830
                 #141406
                 #133009
Filename: add_prisoner.py
 This file contains the dialog window for
 adding a new prisoner.
"""

from PyQt5 import uic
from PyQt5.QtGui import QPixmap
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QApplication, QWidget, QMessageBox, QFileDialog
from PyQt5.QtCore import QDir
from database import DatabaseConnection
from prisoner import Prisoner

QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)


# Class that contains the widget GUI to add the info of a prisoner
class AddPrisonerUI(QWidget):
    def __init__(self):
        super().__init__()
        uic.loadUi("add_prisoner.ui", self)
        self.dir = ""  # Stores the entire directory of an image

        # Connect button click event to method
        self.addPrisoner.clicked.connect(self.add_prisoner_clicked)
        self.backButton.clicked.connect(self.go_back)

    # Opens the directory of the user, and prompts them to select an image for the prisoner
    def open_image(self, filename=None):
        if not filename:
            filename, _ = QFileDialog.getOpenFileName(self, 'Select Photo', QDir.currentPath(), 'Images (*.png *.jpg)')
            if not filename:
                return
        self.image_label.setPixmap(QPixmap(filename))

        self.dir = filename

        image_str = self.image_name(str(filename))

        self.photo_lineEdit.setText(image_str)

    # Takes the directory of the image, and looks for the name of the image
    @staticmethod
    def image_name(directory):
        backslash_index = directory.rfind('/')
        return directory[backslash_index + 1:]

    # Checks that the height entered is valid
    def check_height(self):  # New solution
        if float(self.height_lineEdit.text()) <= 0:
            raise SyntaxError("Please make sure that the entered height is not negative")

        else:
            decimal = round((float(self.height_lineEdit.text()) % 1), 2)
            if decimal >= 0.12:
                raise SyntaxError("Please make sure that the entered height is valid and complies with the following "
                                  "format: 5'7\" as 5.07 (Refer to the help section for more info.)")

    # Adds the new prisoner's personal info into the database
    def add_prisoner_clicked(self):

        try:
            database = DatabaseConnection()

            # Boxes not empty check
            if not (self.addLastName.text()) or not (self.addName.text()) or \
                    not (self.addBirth.text()) or not (self.height_lineEdit.text()) or \
                    not (self.addHair.currentText()) or not (self.addEyes.currentText()) or \
                    not (self.addBirthplace.text()) or not (self.addSentence.text()) or \
                    not (self.addConviction.text()):
                raise ArithmeticError("Please, fill in all of the corresponding boxes (Refer to the help section"
                                      f" for more info.)")

            # Height check
            self.check_height()

            # Image added check
            if not (self.photo_lineEdit.text()):
                raise ArithmeticError("Please, add an image of the prisoner")

            # Date to be Liberated check
            if not (self.addLiberation.text()) or self.addLiberation.text() == "None" \
                    or self.addLiberation.text() == "none":
                dateToBeLiberated = None

            else:
                dateToBeLiberated = self.addLiberation.text()

            prisoner = Prisoner(self.addLastName.text(), self.addName.text(), self.dir,
                                self.addBirth.text(), float(self.height_lineEdit.text()), self.addHair.currentText(),
                                self.addEyes.currentText(), self.addBirthplace.text(),
                                self.addSentence.text(), self.addConviction.text(), dateToBeLiberated)

            rows, id = database.add(prisoner)

            database.close()

            msgBox = QMessageBox()

            if rows == 1:
                msg = f"{rows} record inserted with ID {id}"
                msgBox.setText(msg)
                msgBox.exec()
                self.prisonerAdded.setText("Prisoner successfully added!")
                self.prisonerAdded.setStyleSheet("color: green")
            else:
                msg = "Database error"
                msgBox.setText(msg)
                msgBox.exec()

        except ArithmeticError as ex:
            msgbox = QMessageBox()
            msgbox.setWindowTitle("Error")
            msgbox.setIcon(QMessageBox.Warning)
            msgbox.setText(f"{ex}")
            msgbox.exec_()
        except SyntaxError as ex:
            msgbox = QMessageBox()
            msgbox.setWindowTitle("Error")
            msgbox.setIcon(QMessageBox.Warning)
            msgbox.setText(f"{ex}")
            msgbox.exec_()
        except ValueError:
            msgbox = QMessageBox()
            msgbox.setWindowTitle("Error")
            msgbox.setIcon(QMessageBox.Warning)
            msgbox.setText(f"Enter an integer or decimal number for Height (Refer to the help section "
                           f"for more info.)")
            msgbox.exec_()

    # Goes back to the previous window
    def go_back(self):
        self.hide()
