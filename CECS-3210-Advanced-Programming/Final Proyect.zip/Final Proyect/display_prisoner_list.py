"""
Author's: Coral S. Schmidt Montilla
          Gabriel O. Gonzales Rios
          Kevin Gabriel Quintero Ramires
Student Numbers: #148830
                 #141406
                 #133009
Filename: display_prisoner_list.py
 This file contains the dialog window for
 displaying a list of prisoners.
"""

from PyQt5 import uic
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QStandardItemModel, QStandardItem
from PyQt5.QtWidgets import QWidget, QApplication, QTableView, QPushButton

from database import DatabaseConnection

QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)


# Class that contains the widget GUI that displays a table with the info of all the prisoners in the database
class ListPrisonersUI(QWidget):
    def __init__(self):
        super().__init__()
        uic.loadUi("prisoner_list.ui", self)

        self.tableWidget = self.findChild(QTableView, "tableView")
        self.loadListButton = self.findChild(QPushButton, "loadListButton")
        self.backButton = self.findChild(QPushButton, "backButton")

        self.loadListButton.clicked.connect(self.load_prisoner_list)
        self.backButton.clicked.connect(self.go_back)

    def load_prisoner_list(self):
        database = DatabaseConnection()
        all_prisoners_cursor = database.select_all_prisoners()

        model = QStandardItemModel()
        model.setHorizontalHeaderLabels(['Prisoner ID', 'Last Name', 'First Name', 'Photo', 'Birth Date', 'Height',
                                         'Hair Color', 'Eye Color', 'Place of Birth', 'Sentence', 'Conviction Date',
                                         'Liberation Date'])

        row = 0

        for (prisonerID, lastName, firstName, photo, birthDate, height, hair, eyes, placeOfBirth, sentence,
             dateOfConviction, dateToBeLiberated) in all_prisoners_cursor:
            array_data = [str(prisonerID), lastName, firstName, photo, str(birthDate), str(float(height)), hair, eyes,
                          placeOfBirth, sentence, str(dateOfConviction), str(dateToBeLiberated)]

            for col in range(12):
                item = QStandardItem()

                if col == 3:
                    value = self.image_name(array_data[col])
                elif col == 5:
                    value = f"{array_data[col]}ft/in"
                else:
                    value = array_data[col]

                item.setData(value, Qt.DisplayRole)
                model.setItem(row, col, item)

            row += 1

        self.tableWidget.setModel(model)
        database.close()

    @staticmethod
    def image_name(directory):
        backslash_index = directory.rfind('/')
        return directory[backslash_index + 1:]

    def go_back(self):
        # Logic to go back to the prisoner menu
        # This is a placeholder for actual implementation
        print("Back button pressed. Implement the functionality to go back to the prisoner menu.")


if __name__ == "__main__":
    import sys
    app = QApplication(sys.argv)
    window = ListPrisonersUI()
    window.show()
    sys.exit(app.exec_())
