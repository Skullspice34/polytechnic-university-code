#include <iostream>


int main()
{
	//declare variables
	float a = 62;
	float b = 99;
	float sum = a + b;

	std::cout << "Addition \n";
	std::cout << a; //prints first number
	std::cout << " + ";
	std::cout << b; //prints second number
	std::cout << "\nThis is the sum of both numbers: ";
	std::cout << sum;//prints the sum of both numbers

	return 0;




}
